=== Sailthru for WordPress ===
Contributors: nickgundry, sailthru-wp, automattic, irms, zackify, natebot
Tags: personalization, email,
Requires at least: 3.6
Tested up to: 4.9
Stable tag: 3.1

This plugin  provides fast and easy integration of the core Sailthru features into your Wordpress site.

== Description ==

Provides an integration with Sailthru

== Installation ==

For full installation instructions, documentation, and examples please visit:
http://docs.sailthru.com/integrations/wordpress

== Screenshots ==
1. Welcome Screen with quick links to Sailthru support
2. The setup screen allows you to get up and running with Sailthru in a few clicks.
3. Configure Sailthru's Concierge widget in the WordPress admin. No JavaScript knowledge needed.
4. Configure Scout in the WordPress admin.
5. Add customizable fields to the Signup widget
