<?php
if ( ! class_exists( 'BCMAPI' ) ) {
	require_once( __DIR__ . '/bc-mapi.php' );
	require_once( __DIR__ . '/wp-bc-mapi.php' );
}
