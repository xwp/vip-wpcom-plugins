<?php

require( __DIR__ . '/Autoloader.php' );
Mustache_Autoloader::register();
