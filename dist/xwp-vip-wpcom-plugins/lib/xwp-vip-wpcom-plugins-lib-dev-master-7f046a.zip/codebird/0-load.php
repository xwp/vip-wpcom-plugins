<?php
if ( ! class_exists( 'Codebird' ) ) {
	require_once( __DIR__ . '/codebird.php' );
	require_once( __DIR__ . '/class-wp-codebird.php' );
}
