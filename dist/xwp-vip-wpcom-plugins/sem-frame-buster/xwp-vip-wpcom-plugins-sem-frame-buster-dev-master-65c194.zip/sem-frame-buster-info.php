<?php
__('Frame Buster', 'sem-frame-buster');
__('Thwarts any attempt to load your site in a frame.', 'sem-frame-buster');
?>