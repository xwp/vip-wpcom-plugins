<?php
// This file is needed for the wpcom_vip_load_plugin.

//Load the plugin files.
include_once __DIR__ . '/class-jquery-migrate-helper.php';
// plugins were already loaded, init the actions!
jQuery_Migrate_Helper::init_actions();
