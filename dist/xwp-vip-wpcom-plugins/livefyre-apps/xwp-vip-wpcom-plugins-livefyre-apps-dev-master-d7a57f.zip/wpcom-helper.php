<?php

// Cache full site comment count that gets called on every page load.
wpcom_vip_enable_cache_full_comment_counts();