<?php
/**
 * Publish to Apple News partials: Index dummy template
 *
 * @package Apple_News
 */

// Silence is golden.

