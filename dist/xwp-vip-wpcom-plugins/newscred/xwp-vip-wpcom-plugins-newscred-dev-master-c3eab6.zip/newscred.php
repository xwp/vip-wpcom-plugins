<?php

// Bootstrap for wpcom_vip_load_plugin
require( __DIR__ . '/newscred-wp.php' );
