<p class="hide-if-no-js">
    <a title="Set featured image"
       href="<?php echo esc_url( $this->image_url . "&amp;type=image&amp;TB_iframe=1&amp;width=640&amp;height=306");?>"
       id="set-post-thumbnail" class="thickbox">Set featured image</a>
</p>