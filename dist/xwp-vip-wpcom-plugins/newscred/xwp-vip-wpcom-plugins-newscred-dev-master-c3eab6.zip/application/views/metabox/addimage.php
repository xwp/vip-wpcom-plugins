<?php if ( $this->image_url ) { ?>
<p class="hide-if-no-js">
    <img width="260" height="178  class=" attachment-266x266" src="<?php  echo esc_url( $this->image_url ); ?>">
</p>
<p class="hide-if-no-js">
    <a href="javascript:void(0)" id="nc-remove-post-thumbnail">Remove featured image</a>
</p>
<?php } ?>
