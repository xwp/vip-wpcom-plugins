<div class="update-nag" style="margin-top: 5px">
    <?php $active_url =esc_url( wp_nonce_url(  NC_PLUGIN_ACTIVE_URL, 'myfeed_active_plugin_nonce')); ?>
    Please activate <strong><a href="<?php echo $active_url;?>" > NewsCred Content Feeds Plugin</a></strong> for this blog .
</div>