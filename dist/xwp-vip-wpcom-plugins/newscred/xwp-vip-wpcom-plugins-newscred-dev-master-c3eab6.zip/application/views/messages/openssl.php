<div class="update-nag" style="margin-top: 5px">
    Please enable the <strong><a href="http://php.net/manual/en/book.openssl.php" target="_blank">OpenSSL</a></strong>
    to work NewsCred plugin properly.
</div>