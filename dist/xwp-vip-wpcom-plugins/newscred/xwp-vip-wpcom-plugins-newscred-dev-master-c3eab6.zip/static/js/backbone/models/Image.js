ncApp.Image = Backbone.Model.extend( {
    defaults:{
        guid:null,
        caption:null,
        description:null,
        attribution_text:null,
        published_at:null,
        source:null,
        image_large:null

    }
} );