ncApp.Tag = Backbone.Model.extend( {
    defaults:{
        name:null,
        guid:null,
        type:null
    }
} );