ncApp.Tags = Backbone.Collection.extend( {
    model:ncApp.Tag
} );