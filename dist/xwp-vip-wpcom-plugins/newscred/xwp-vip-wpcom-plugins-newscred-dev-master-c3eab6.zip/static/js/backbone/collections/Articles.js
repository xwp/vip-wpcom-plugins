ncApp.Articles = Backbone.Collection.extend( {
    model:ncApp.Article
} );