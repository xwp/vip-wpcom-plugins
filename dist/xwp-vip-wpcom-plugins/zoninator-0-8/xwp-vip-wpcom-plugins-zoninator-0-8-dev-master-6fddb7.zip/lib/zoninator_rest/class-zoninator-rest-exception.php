<?php
/**
 * Mixtape_Exception
 *
 * @package Mixtape
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base Exception class
 * Class Zoninator_REST_Exception
 */
class Zoninator_REST_Exception extends Exception {
}
