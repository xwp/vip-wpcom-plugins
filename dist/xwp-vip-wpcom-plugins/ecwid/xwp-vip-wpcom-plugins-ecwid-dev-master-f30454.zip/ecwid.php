<?php

// Bootstrap file to allow wpcom_vip_load_plugin to work
require( __DIR__ . '/ecwid-wordpress-shortcode.php' );
