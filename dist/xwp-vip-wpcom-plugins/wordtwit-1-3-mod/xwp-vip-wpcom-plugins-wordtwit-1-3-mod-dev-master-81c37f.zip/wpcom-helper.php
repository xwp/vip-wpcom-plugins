<?php

/**
 * Deprecated: Use Publicize (http://en.support.wordpress.com/publicize/)
 */
