<?php

// This file is here for legacy reasons. For up-to-date shortcodes, please install the Jetpack plugin (http://jetpack.me)
