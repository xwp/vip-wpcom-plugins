<?php
/*
Plugin Name: Powered by WordPress.com VIP
Description: Provide functions and a widget that can be used to display a 'Powered by WordPress.com VIP" text or image link.
Version: 1.0
Author: Nick Momrik

This plugin is automatically enabled on all WordPress.com VIP blogs and is provided here for your local test environments.
Use the widget in your sidebar or the functions in your theme.
*/


/**
 * Returns the "Powered by WordPress.com VIP" widget's content.
 *
 * @link http://vip.wordpress.com/documentation/code-and-theme-review-process/ Code Review
 * @link http://vip.wordpress.com/documentation/powered-by-wordpress-com-vip/ Powered By WordPress.com VIP
 * @param string $display Optional. Either: 1-6 or "text"*. If an integer, wrap an image in the VIP link. Otherwise, just return the link.  
 * @param string $before_text Optional. Text to go in front of the VIP link. Defaults to 'Powered by '.
 * @return string HTML
 */
function vip_powered_wpcom( $display = 'text', $before_text = 'Powered by ' ) {
	$output = $before_text . '<a href="' . esc_url( vip_powered_wpcom_url() ) . '" rel="generator nofollow" class="powered-by-wpcom">WordPress.com VIP</a>';
	return $output;
}

/**
 * Returns the URL to the WordPress.com VIP site
 *
 * @return string
 */
function vip_powered_wpcom_url() {
	$args = array(
		'utm_source' => 'vip_powered_wpcom',
		'utm_medium' => 'web',
		'utm_campaign' => 'VIP Footer Credit',
		'utm_term' => sanitize_text_field( $_SERVER['HTTP_HOST'] ),
	);

	return add_query_arg( $args, 'https://wpvip.com/' );
}
