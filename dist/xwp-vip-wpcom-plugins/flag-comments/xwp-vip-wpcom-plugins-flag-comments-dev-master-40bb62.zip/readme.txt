=== Flag Comments ===
Contributors: watershedstudio
Donate link: http://watershedstudio.com/portfolio/software-development/flag-comments/
Tags: comments, flag, flagging
Requires at least: 2.2.0
Tested up to: 2.6.1
Stable tag: 1.7

Allows readers to flag WordPress comments as inappropriate.

== Description ==

Flag Comments allows readers to flag WordPress comments as inappropriate.

Released under the terms of the GNU GPL, version 2.
   http://www.fsf.org/licensing/licenses/gpl.html

              NO WARRANTY.

	Copyright (c) 2008 Watershed Studio, LLC

== Installation ==
1. Copy the flag-comments.php file to /wp-content/plugins/
1. Activate the plugin at your blog's Admin -> Plugins screen
