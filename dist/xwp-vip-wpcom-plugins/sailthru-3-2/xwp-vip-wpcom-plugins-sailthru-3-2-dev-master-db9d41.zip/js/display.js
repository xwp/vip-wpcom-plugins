(function ($) {
	"use strict";
	$(function () {
		//  public-facing JavaScript here
	});
}(jQuery));