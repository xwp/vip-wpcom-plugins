<?php
/**
 * Allow the plugin to be loaded from a theme too
 */
add_action( 'after_setup_theme', 'Document_Feedback' );