(function (window, $) {

	var pbAllPostsController = new window.PbAllPostsController( $ );

	pbAllPostsController.init();

})( window, window.jQuery );
