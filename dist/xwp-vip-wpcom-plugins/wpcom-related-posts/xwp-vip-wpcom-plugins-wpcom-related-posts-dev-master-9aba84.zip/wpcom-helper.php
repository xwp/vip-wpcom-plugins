<?php
/**
 * Ensure WordPress.com Related Posts is instantiated
 */
add_action( 'after_setup_theme', 'WPCOM_Related_Posts' );