<?php
namespace Apple_Actions;

class Action_Exception extends \Exception {}
