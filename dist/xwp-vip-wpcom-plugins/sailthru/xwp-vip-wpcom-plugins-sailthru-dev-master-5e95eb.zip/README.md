sailthru-wordpress-plugin
=========================

widget usage:
[sailthru_widget fields="names,of,fields" modal=true]
