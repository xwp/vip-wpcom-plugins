=== Plugin Name ===
Contributors: nickgundry, automattic (this should be a list of wordpress.org userid's)
Tags: personalization, email,
Requires at least: 3.3.1
Tested up to: 3.3.1
Stable tag: 3.0

This plugin  provides fast and easy integration of the core Sailthru features into your Wordpress site.

== Description ==

UNDER DEVELOPMENT

* Automatically adds Horizon Javascript to pages
* Automatically adds Sailthru Meta Tags to all posts
* Admin area to configure Sailthru Scout and the Sailthru Concierge Slider
* Adds a page to provides personalized recommendations for users
* Widget for simple email subscription
* Widget for "personalized" content for the user via Sailthru Scout
* Recommended content using Sailthru Concierge
*  All Wordpress emails re-routed to use Sailthru's email service.

== Installation ==

For full installation instructions, documentation, and examples please visit:
http://getstarted.sailthru.com/developers/api-libraries/wordpress

==== Sailthru Specific ====
Create a template in your Sailthru account with {subject} as the subject line and {body} in the code area.
You can design your template to match your brand but the {body} variable will be replaced by content
sent via Wordpress

==== Wordpress Installation =====

For full installation instructions, documentation, and examples please visit:
http://getstarted.sailthru.com/developers/api-libraries/wordpress

