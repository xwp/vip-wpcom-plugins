<?php

// Bootstrap to allow wpcom_vip_load plugin to work
require( __DIR__ . '/plugin.php' );
