<?php

class Sailthru_Client_Exception extends Exception {

}