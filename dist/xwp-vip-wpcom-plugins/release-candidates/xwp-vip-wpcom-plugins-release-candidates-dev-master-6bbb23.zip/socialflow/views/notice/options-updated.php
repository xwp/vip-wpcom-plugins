<?php
/**
 * Template for displaying options page updated notice
 *
 * @since 2.0
 */
?>
<div id="sf-initial-nag" class="updated">
	<p><strong><?php esc_html_e( 'Settings were successfully updated', 'socialflow' ) ?></strong></p>
</div>