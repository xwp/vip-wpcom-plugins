<div class="bbl-translation-property bbl-translation-property-post_excerpt">
	<textarea class="regular-text" name="bbl_translation[post][post_excerpt]"><?php echo esc_textarea( $translation->post_excerpt ); ?></textarea>
</div>
<div class="bbl-translation-original bbl-translation-original-post_excerpt">
	<textarea class="regular-text" readonly><?php echo esc_textarea( $original->post_excerpt ); ?></textarea>
</div>