<?php
	$text_direction = "rtl";