<?php
//Helper file for loading Babble's translation group tool

require_once dirname( dirname( __FILE__ ) ) . '/babble/translation-group-tool.php';
