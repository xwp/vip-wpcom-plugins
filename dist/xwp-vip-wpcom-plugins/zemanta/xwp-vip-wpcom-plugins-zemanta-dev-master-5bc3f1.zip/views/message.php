

<div class="<?php echo esc_attr( $type ); ?>">
  
  <p>
    <strong><?php echo esc_html( $message ); ?></strong>
  </p>

</div>