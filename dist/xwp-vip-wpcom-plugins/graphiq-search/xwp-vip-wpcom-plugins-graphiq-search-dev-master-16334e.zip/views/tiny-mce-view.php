<script type="text/html" id="tmpl-editor-graphiq">
	<div class="graphiq-tiny-mce-view" style="width:{{ data.width }}px;height:{{ data.height }}px;">
		<div class="graphiq-tiny-mce-view-title-wrap">
			<div class="graphiq-tiny-mce-view-title-center">
				<div class="graphiq-tiny-mce-view-image"></div>
				<div class="graphiq-tiny-mce-view-title">{{ data.title }}</div>
			</div>
		</div>
	</div>
</script>