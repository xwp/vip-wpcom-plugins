<span class="graphiq-media-button button" title="<?php echo esc_attr( $vars['title'] ); ?>" data-editor="content">
	<span class="graphiq-media-button-icon vm"></span> <span class="graphiq-media-button-text"><?php echo esc_html( $vars['title'] ); ?></span>
</span>