.graphiq-amp-iframe {
	background: #fff;
}
.graphiq-amp-link {
	text-align: center;
}
.graphiq-amp-link a {
	font:14px/16px arial;color:#3d3d3d;
}
