<div class="mp-wrap">
	<h2 class="header"><img width="24" height="24" src="<?php echo plugins_url('/images/logo-icon.png', dirname(__FILE__)) ?>" class="mp-icon"> De-Authorize Plugin</h2>
	<p>Are you sure you want to de-authorize this plugin?</p>
	<p><a href="<?php echo menu_page_url('mediapass_deauth',false)?>&deauth=true">Click here to de-authorize this plugin and unlink your MediaPass account.</a></p>
</div>
		