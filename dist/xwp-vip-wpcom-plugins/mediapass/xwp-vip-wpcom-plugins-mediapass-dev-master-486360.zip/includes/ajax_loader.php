<div class="ajax-loader">
	<h2><img src="<?php echo plugins_url('/images/ajax-loader.gif') ?>" alt="loading"> Loading your information...</h2>
</div>