<div class="mp-wrap">
	<h2>There was an error retrieving the data from your account.</h2>
	<p>Please try again in a few minutes. If you keep having issues please email us at: <a href="mailto:&#x70;&#x75;&#x62;&#x6C;&#x69;&#x73;&#x68;&#x65;&#x72;&#x40;&#x6D;&#x65;&#x64;&#x69;&#x61;&#x70;&#x61;&#x73;&#x73;&#x2E;&#x63;&#x6F;&#x6D;">publisher@mediapass.com</a>.</p>
	<p><em>Error Reference: <?php echo var_dump($error) ?></em></p>
	<?php var_dump($response); ?>
	<?php var_dump($data); ?>
</div>