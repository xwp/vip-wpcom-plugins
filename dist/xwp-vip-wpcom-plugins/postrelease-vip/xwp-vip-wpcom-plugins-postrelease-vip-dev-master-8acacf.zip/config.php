<?php
define('PRX_DEV', false); //set to false in production (when equals true: disables security check)
define('PRX_POSTRELEASE_SERVER','http://www.postrelease.com');
define('PRX_JAVASCRIPT_URL','http://a.postrelease.com/serve/load.js?async=true'); //http://a.postrelease.com/serve/load.js?async=true