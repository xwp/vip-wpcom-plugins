=== Shopify for WordPress ===
Contributors: Wesley Ellis
Tags: shopify, e-commerce, shopping
Requires at least: 3.0.1
Tested up to: 3.8
Stable tag: 0.2
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed Shopify products in your WordPress blog with ease

== Description ==

Shopify for WordPress allows you to embed your Shopify products inside of your 
blog

== Installation ==

1. Upload `shopify` to the `/wp-content/plugins/` directory
1. Activate "Shopify for WordPress" on the "Plugins" page
1. Finish installation by clicking on "Shopify" in the "Settings" menu

== Changelog ==

= 0.2 =
* Help sections
* Companion app on Shopify
* Live widget preview in settings

= 0.1 =
* Working embed widgets


