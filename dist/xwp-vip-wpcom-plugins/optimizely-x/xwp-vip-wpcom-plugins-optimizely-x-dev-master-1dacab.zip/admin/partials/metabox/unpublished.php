<?php
/**
 * Optimizely X admin metabox partials: Unpublished template
 *
 * @package Optimizely_X
 * @since 1.0.0
 */

?>

<p><?php esc_html_e( 'You must first publish this post before creating the experiment on Optimizely.', 'optimizely-x' ); ?></p>
