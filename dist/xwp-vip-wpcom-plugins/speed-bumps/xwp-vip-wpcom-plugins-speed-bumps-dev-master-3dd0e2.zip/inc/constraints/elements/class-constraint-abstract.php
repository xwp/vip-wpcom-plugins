<?php
namespace Speed_Bumps\Constraints\Elements;

abstract class Constraint_Abstract {
	abstract function paragraph_not_contains_element( $paragraph );
}
