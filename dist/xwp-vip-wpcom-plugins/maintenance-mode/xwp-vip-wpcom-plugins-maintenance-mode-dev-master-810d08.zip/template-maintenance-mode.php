<html>
<head>
	<?php wp_head(); // allow for remote-login on mapped domains ?>
</head>
<body>
	<h1>Howdy!</h1>
	<p>We're just freshening things up a bit; back in a few!</p>
	<?php wp_footer(); ?>
</body>
</html>
