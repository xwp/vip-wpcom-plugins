( function( $ ) {
	$( '#js-start-date' ).datetimepicker( {
		dateFormat: 'yy-mm-dd',
		ampm: true
	} );
} )( jQuery );
