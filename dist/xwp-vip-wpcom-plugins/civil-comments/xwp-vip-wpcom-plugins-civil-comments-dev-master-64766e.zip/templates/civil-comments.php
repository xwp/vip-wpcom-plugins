<?php
/**
 * Civil Comments Template
 *
 * @package Civil_Comments
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="comments" class="comments-area">
	<?php show_civil_comments(); ?>
</div><!-- .comments-area -->
