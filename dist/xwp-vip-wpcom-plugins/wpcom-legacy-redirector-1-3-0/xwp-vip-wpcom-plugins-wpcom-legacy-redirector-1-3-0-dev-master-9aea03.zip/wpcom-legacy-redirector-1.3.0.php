<?php
require_once( __DIR__ . '/wpcom-legacy-redirector.php' );
