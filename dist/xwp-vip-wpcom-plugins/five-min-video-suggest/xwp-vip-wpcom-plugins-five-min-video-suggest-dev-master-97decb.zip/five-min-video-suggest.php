<?php
// Bootstrap to allow wpcom_vip_load_plugin to work.
require_once( __DIR__ . '/FiveMinVideoSuggest.php' );
