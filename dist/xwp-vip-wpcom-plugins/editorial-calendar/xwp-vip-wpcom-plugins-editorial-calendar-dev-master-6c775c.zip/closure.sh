java -jar closure/compiler.jar --js_output_file lib/edcallib.min.js --js lib/humanmsg.js --js lib/sprintf-0.7-beta1.js --js lib/jquery.cookie.js --js lib/jquery.bgiframe.js --js lib/jquery.delegate.js --js lib/jquery.tools.min.js --js lib/jquery.timepicker.js --js lib/json2.js --js lib/tools.scrollable-1.1.2.js --js lib/tools.scrollable.mousewheel-1.0.1.js --js lib/date.extras.js

java -jar closure/compiler.jar --js_output_file edcal.min.js --js edcal.js
