=== Expiring Posts ===
Contributors: ivankk
Tags: post-expiry, expiring-posts, expire
Requires at least: 3.0.1
Tested up to: 5.1
Requires PHP: 5.3
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin adds functionality to expire a post on a given date.

It does this by adding a new "Expires" date field in the Publish box.
