eval(STIPPLE_SETTINGS.custom_loader);
