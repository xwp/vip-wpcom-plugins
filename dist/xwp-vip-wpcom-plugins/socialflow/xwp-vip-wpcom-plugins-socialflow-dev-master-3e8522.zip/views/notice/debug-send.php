<?php
/**
 * Template for displaying options page updated notice
 *
 * @since 2.0
 */
?>
<div id="sf-initial-nag" class="updated">
	<p><strong><?php esc_html_e( 'Debug information was successfully sent', 'socialflow' ) ?></strong></p>
</div>