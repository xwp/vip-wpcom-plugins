=== Hidden Posts ===
Contributors: automattic, betzster, batmoo
Tags: posts
Requires at least: 3.8
Tested up to: 3.8
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The opposite of sticky posts.

== Description ==

Hide a limited number of specified posts from the hompage.

If you'd like to check out the code and contribute, [join us on GitHub](https://github.com/Automattic/hidden-posts). Pull requests, issues, and plugin recommendations are more than welcome!

== Installation ==

1. Upload the `hidden-posts` folder to your plugins directory (e.g. `/wp-content/plugins/`)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Hide posts from the post edit screen

== Frequently Asked Questions ==

= Why are there no FAQs besides this one? =

Because you haven't asked one yet.

== Changelog ==

= 0.1 =
* Initial Release
