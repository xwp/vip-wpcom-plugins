<?php

// This file is only here so that we can include based on folder name

include( 'breadcrumb_navxt_admin.php' );

?>