<?php
/*
Plugin Name: Multiple Post Thumbnails
Plugin URI: http://wordpress.org/extend/plugins/multiple-post-thumbnails/
Description: Adds the ability to add multiple post thumbnails to a post type.
Version: 1.6
Author: Chris Scott
Author URI: http://voceplatforms.com/
*/

// This file is only here so that we can include based on folder name

include_once( 'multi-post-thumbnails.php' );

?>