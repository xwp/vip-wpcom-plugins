<?php
require( 'livefyre.php' ); // bootstrap to work with wpcom_vip_load_plugin()
