<script type="text/html" id="tmpl-editor-findthebest">
	<div class="ftb-tiny-mce-view" style="width:{{ data.width }}px;height:{{ data.height }}px;">
		<div class="ftb-tiny-mce-view-title-wrap">
			<div class="ftb-tiny-mce-view-title-center">
				<div class="ftb-tiny-mce-view-image"></div>
				<div class="ftb-tiny-mce-view-title">{{ data.title }}</div>
			</div>
		</div>
	</div>
</script>