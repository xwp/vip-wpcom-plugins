<div id="ftb-sidebar">
	<div class="nav-bar">
		<div class="static-bar">
			<div class="search-bar">
				<input type="text" class="ftb-search-input vm" placeholder="<?php esc_attr_e( 'Search', 'findthebest' ); ?>">
				<a class="button ftb-search-button vm" title="<?php esc_attr_e( 'Search for content', 'findthebest' ); ?>"><span style="background-image:url('<?php echo esc_url( $vars[ 'image_dir' ] ); ?>search.png')" class="ftb-search-icon"></span></a>
			</div>
		</div>
	</div>
</div>
