<span class="ftb-media-button button" title="<?php echo esc_attr( $vars['title'] ); ?>" data-editor="content">
	<span class="ftb-media-button-icon vm"></span> <span class="ftb-media-button-text"><?php echo esc_html( $vars['title'] ); ?></span>
</span>