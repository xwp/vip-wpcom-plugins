<div class="error">
	<p>
		<?php echo esc_html( $message ); ?>
	</p>
</div>
