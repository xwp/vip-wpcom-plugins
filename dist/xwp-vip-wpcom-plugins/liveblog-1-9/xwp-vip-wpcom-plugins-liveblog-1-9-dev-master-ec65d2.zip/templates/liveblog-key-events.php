<?php if( 'false' != $title ): ?>
	<div id="liveblog-key-events" data-title="<?php echo esc_attr( $title ) ?>"></div>
<?php else: ?>
	<div id="liveblog-key-events"></div>
<?php endif;
