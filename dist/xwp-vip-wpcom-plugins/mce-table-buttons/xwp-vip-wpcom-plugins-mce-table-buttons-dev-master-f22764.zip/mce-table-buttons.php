<?php

require_once( __DIR__ . '/mce_table_buttons.php' );
