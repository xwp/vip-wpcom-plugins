/**
 * The licence key to use with the self-hosted player
 * @author ilGhera
 * @package jw-player-for-vip/js
* @version 2.0.0
 */

var licence = data.licence;
jwplayer.key = licence;
