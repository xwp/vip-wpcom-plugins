var Shortcode = require('../../js/src/models/shortcode');
var InnerContent = require('../../js/src/models/inner-content');
var ShortcodeAttribute = require('../../js/src/models/shortcode-attribute');
var ShortcodeAttributes = require('../../js/src/collections/shortcode-attributes');
var $ = require('jquery');

describe( "Shortcode Model", function() {

	var defaultShortcode, shortcode, data;

	data = {
		label: 'Test Label',
		shortcode_tag: 'test_shortcode',
		attrs: [
			{
				attr:        'attr',
				label:       'Attribute',
				type:        'text',
				value:       'test value',
				placeholder: 'test placeholder'
			}
		],
		inner_content: {
			value: 'test content',
		},
	};

	defaultShortcode = new Shortcode();
	shortcode = new Shortcode( data );

	it( 'Defaults set correctly.', function() {
		expect( defaultShortcode.get( 'label' ) ).toEqual( '' );
		expect( defaultShortcode.get( 'shortcode_tag' ) ).toEqual( '' );
		expect( defaultShortcode.get( 'attrs' ) instanceof ShortcodeAttributes ).toEqual( true );
		expect( defaultShortcode.get( 'attrs' ).length ).toEqual( 0 );
		expect( defaultShortcode.get( 'inner_content' ) ).toEqual( undefined );
	});

	it( 'Attribute data set correctly..', function() {
		expect( shortcode.get( 'attrs' ) instanceof ShortcodeAttributes ).toEqual( true );
		expect( shortcode.get( 'attrs' ).length ).toEqual( 1 );
		expect( shortcode.get( 'attrs' ).first().get('type') ).toEqual( data.attrs[0].type );
	});

	it( 'Inner content set correctly..', function() {
		expect( shortcode.get( 'inner_content' ) instanceof InnerContent ).toEqual( true );
		expect( shortcode.get( 'inner_content' ).get('value') ).toEqual( data.inner_content.value );
	});

	it( 'Converted to JSON correctly.', function() {
		var json = shortcode.toJSON();
		expect( json.label ).toEqual( data.label );
		expect( json.attrs[0].label ).toEqual( data.attrs[0].label );
	});

	it( 'Format shortcode.', function() {

		var _shortcode = jQuery.extend( true, {}, shortcode );

		// Test with attribute and with content.
		expect( _shortcode.formatShortcode() ).toEqual( '[test_shortcode attr="test value"]test content[/test_shortcode]' );

		// Test without content.
		_shortcode.get('inner_content').unset( 'value' );
		expect( _shortcode.formatShortcode() ).toEqual( '[test_shortcode attr="test value" /]' );

		// Test without attributes
		_shortcode.get( 'attrs' ).first().unset( 'value' );
		expect( _shortcode.formatShortcode() ).toEqual( '[test_shortcode /]' );

	});

	it( 'Format shortcode with encoded attributes.', function() {

		var shortcode_encoded_attribute, formatted, expected;

		shortcode_encoded_attribute = new Shortcode({
			label: 'Test Label',
			shortcode_tag: 'test_shortcode_encoded',
			attrs: [
				{
					attr:   'attr',
					type:   'text',
					value:  '<b class="foo">bar</b>',
					encode: true,
				},
			],
		});

		formatted = shortcode_encoded_attribute.formatShortcode();
		expected  = '[test_shortcode_encoded attr="%3Cb%20class%3D%22foo%22%3Ebar%3C%2Fb%3E" /]';
		expect( formatted ).toEqual( expected );

	});

});
