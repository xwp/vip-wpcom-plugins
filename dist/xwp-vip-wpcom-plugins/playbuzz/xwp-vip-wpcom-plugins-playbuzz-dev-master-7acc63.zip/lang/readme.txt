== Translators ==

If you have created your own translation, or have an update to an existing one, please send it to publishers@playbuzz.com so we can bundle it into the next release of the plugin.

Thank you.
