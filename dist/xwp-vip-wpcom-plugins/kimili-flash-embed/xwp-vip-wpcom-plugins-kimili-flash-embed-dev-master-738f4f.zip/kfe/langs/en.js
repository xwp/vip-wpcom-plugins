// English lang variables  
tinyMCE.addI18n('', {  
	kfe_desc : "Insert a Kimili Flash Embed Tag." 
});
