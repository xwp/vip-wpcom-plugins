# Lightweight Term Count Update

This plugin prevents WordPress from running term count queries.

Rather, it will instead perform a simple increment/decrement on the post count that does not require a recalculation.