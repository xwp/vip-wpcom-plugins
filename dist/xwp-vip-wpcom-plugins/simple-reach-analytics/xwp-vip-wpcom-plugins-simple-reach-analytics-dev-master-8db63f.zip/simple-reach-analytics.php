<?php

// Bootstrap the plugin so our wpcom_vip_load_plugin function works
require( __DIR__ . '/sranalytics.php' );
