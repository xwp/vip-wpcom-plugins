<?php

/*
  Plugin Name: Objects to Objects
  Version:     1.4.5
  Plugin URI:  http://voceplatforms.com
  Description: A WordPress plugin/module that provides the ability to map relationships between posts and other post types.
  Author:      Voce Platforms
  Author URI:  http://voceplatforms.com/
 */

if ( defined( 'ABSPATH' ) ) {
  require_once __DIR__ . '/loader.php';
}