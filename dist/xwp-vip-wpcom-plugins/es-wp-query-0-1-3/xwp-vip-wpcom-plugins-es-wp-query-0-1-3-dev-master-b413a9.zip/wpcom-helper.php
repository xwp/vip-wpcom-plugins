<?php

// On WordPress.com, we always want to load the 'wpcom-vip' adapter
es_wp_query_load_adapter( 'wpcom-vip' );